def insert_array(list1, element):
    list1.append(element)
    return list1

list1 = [1, 2]
new_list = insert_array(list1, 3)
print(new_list)  # Output: [1, 2, 3]